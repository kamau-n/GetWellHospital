<?php

$con=mysqli_connect("localhost","new_user","password","getwell");
?>